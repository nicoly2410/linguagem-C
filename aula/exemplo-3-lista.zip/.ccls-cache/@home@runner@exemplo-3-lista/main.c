#include <stdio.h>

// Fazendo a multiplicação de dois numeros
int main() {
  // Declrando as variaveis
  float num1, num2, mult;
  printf("Digite o primeiro numero: ");
  scanf("%f", &num1);
  printf("Digite o segundo numero: ");
  scanf("%f", &num2);
  // Cauculo do divisao
  mult = num1 * num2;

  // Saida do resultado
  printf("O resultado é: %f\n", mult);

  return 0;
}